# CarePath AI — starter prototype

A responsive web app and installable Progressive Web App (PWA), using HTML, CSS, JavaScript, Python Flask and SQLite.

## 1. Requirements
- Python 3.10 or newer
- Internet connection for the optional Google Fonts stylesheet

## 2. Run on Windows
Open Command Prompt or PowerShell in this folder:

```bash
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000

## 3. Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000

## 4. Use on an Android phone
For local testing, your phone and computer must be on the same Wi-Fi network. Change the last line of `app.py` to:

```python
app.run(debug=False, host="0.0.0.0", port=5000)
```

Find your computer's local IP address and visit `http://YOUR-IP:5000` on your phone. For PWA installation, browsers generally require HTTPS or localhost; deploy the app to an HTTPS host before installing it. Do not expose the development server directly to the public internet.

## Included in this prototype
- Responsive patient-facing website
- PWA manifest and service worker
- Sample hospital discovery
- Demonstration queue estimate endpoint
- Appointment request form stored in SQLite
- Basic doctor appointment-request view
- Emergency request logging endpoint (not connected to emergency services)

## API endpoints
- `GET /api/hospitals`
- `GET /api/queue/<hospital_id>`
- `POST /api/appointments`
- `GET /api/doctor/appointments`
- `POST /api/emergency`

## Important safety and production notes
This is an educational prototype, not a clinically validated or production-ready healthcare system. All hospital and queue data are illustrative. Appointment requests are not confirmed bookings. The emergency API only records a request in the local database; it does not call 112, dispatch an ambulance or notify a hospital.

Before real-world deployment:
- Integrate only with hospitals that have authorized data sharing and verified queue feeds.
- Add secure authentication, role-based access control, HTTPS, input validation, rate limiting, audit logs and encrypted backups.
- Complete privacy, consent, retention and applicable Indian healthcare/data-protection compliance reviews.
- Do not store real patient health information in this demo.
- Use validated traffic/map APIs and clearly label estimates.
- Have qualified clinical, legal and security professionals review emergency workflows and all patient-facing claims.
