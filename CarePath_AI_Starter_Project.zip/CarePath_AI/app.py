from flask import Flask, jsonify, render_template, request
from pathlib import Path
import sqlite3
from datetime import datetime, timezone
import random

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "carepath.db"
app = Flask(__name__)

# Clearly labelled demo data. Replace with authorized hospital integrations.
HOSPITALS = [
    {"id": 1, "name": "City Care Hospital", "area": "Central Bengaluru", "specialty": "Multi-speciality", "queue": 4, "avg_minutes": 8},
    {"id": 2, "name": "GreenLife Medical Centre", "area": "Indiranagar", "specialty": "General & Emergency", "queue": 7, "avg_minutes": 6},
    {"id": 3, "name": "Sunrise Health Clinic", "area": "Jayanagar", "specialty": "Family Medicine", "queue": 2, "avg_minutes": 12},
]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                hospital_id INTEGER NOT NULL,
                preferred_time TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS emergency_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                location TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            )
        """)

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/hospitals")
def hospitals():
    return jsonify({"demo": True, "hospitals": HOSPITALS})

@app.get("/api/queue/<int:hospital_id>")
def queue(hospital_id):
    hospital = next((h for h in HOSPITALS if h["id"] == hospital_id), None)
    if not hospital:
        return jsonify({"error": "Hospital not found"}), 404
    # Demonstration estimate only; not a clinical or live hospital prediction.
    estimated = hospital["queue"] * hospital["avg_minutes"]
    return jsonify({
        "demo": True,
        "hospital_id": hospital_id,
        "people_waiting": hospital["queue"],
        "estimated_wait_minutes": estimated,
        "message": "Sample estimate. Confirm waiting time directly with the hospital."
    })

@app.post("/api/appointments")
def create_appointment():
    data = request.get_json(silent=True) or {}
    required = ["patient_name", "phone", "hospital_id", "preferred_time"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return jsonify({"error": "Please complete all required fields."}), 400
    try:
        hospital_id = int(data["hospital_id"])
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid hospital selection."}), 400
    if not any(h["id"] == hospital_id for h in HOSPITALS):
        return jsonify({"error": "Please choose a listed hospital."}), 400

    with db() as conn:
        cur = conn.execute(
            """INSERT INTO appointments
            (patient_name, phone, hospital_id, preferred_time, created_at)
            VALUES (?, ?, ?, ?, ?)""",
            (data["patient_name"].strip(), data["phone"].strip(), hospital_id,
             data["preferred_time"].strip(), datetime.now(timezone.utc).isoformat())
        )
        appointment_id = cur.lastrowid
    return jsonify({
        "success": True,
        "appointment_id": appointment_id,
        "message": "Demo appointment request saved. This is not a confirmed hospital booking."
    }), 201

@app.post("/api/emergency")
def emergency():
    data = request.get_json(silent=True) or {}
    required = ["patient_name", "phone", "location"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return jsonify({"error": "Name, phone and location are required."}), 400
    with db() as conn:
        cur = conn.execute(
            """INSERT INTO emergency_requests
            (patient_name, phone, location, details, created_at)
            VALUES (?, ?, ?, ?, ?)""",
            (data["patient_name"].strip(), data["phone"].strip(),
             data["location"].strip(), data.get("details", "").strip(),
             datetime.now(timezone.utc).isoformat())
        )
    return jsonify({
        "success": True,
        "request_id": cur.lastrowid,
        "message": "Demo emergency request recorded only. No ambulance, hospital or emergency service has been contacted."
    }), 201

@app.get("/api/doctor/appointments")
def doctor_appointments():
    with db() as conn:
        rows = conn.execute("""
            SELECT a.id, a.patient_name, a.phone, a.preferred_time, a.created_at,
                   h.name AS hospital_name
            FROM appointments a JOIN (
                SELECT 1 AS id, 'City Care Hospital' AS name
                UNION SELECT 2, 'GreenLife Medical Centre'
                UNION SELECT 3, 'Sunrise Health Clinic'
            ) h ON h.id = a.hospital_id
            ORDER BY a.id DESC
        """).fetchall()
    return jsonify({"appointments": [dict(r) for r in rows]})

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
