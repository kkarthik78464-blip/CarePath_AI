const hospitalList = document.getElementById("hospitalList");
const hospitalSelect = document.getElementById("hospitalSelect");
const appointmentForm = document.getElementById("appointmentForm");
const appointmentMessage = document.getElementById("appointmentMessage");

async function loadHospitals() {
  try {
    const response = await fetch("/api/hospitals");
    const data = await response.json();
    hospitalList.innerHTML = "";
    data.hospitals.forEach(h => {
      const card = document.createElement("article");
      card.className = "hospital-card";
      card.innerHTML = `
        <span class="demo-tag">SAMPLE HOSPITAL</span>
        <h3>${escapeHtml(h.name)}</h3>
        <p>${escapeHtml(h.area)} · ${escapeHtml(h.specialty)}</p>
        <div class="hospital-meta"><span>People waiting</span><strong>${h.queue} (sample)</strong></div>
        <div class="hospital-actions">
          <button class="btn btn-outline" data-queue="${h.id}">Queue estimate</button>
          <a class="btn" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(h.name + " " + h.area)}">Map ↗</a>
        </div>
        <p class="queue-result" id="queue-${h.id}" aria-live="polite"></p>`;
      hospitalList.appendChild(card);
      const option = document.createElement("option");
      option.value = h.id;
      option.textContent = h.name;
      hospitalSelect.appendChild(option);
    });
    hospitalList.querySelectorAll("[data-queue]").forEach(btn => {
      btn.addEventListener("click", () => loadQueue(btn.dataset.queue));
    });
  } catch {
    hospitalList.textContent = "Could not load demo hospitals. Check that the Python server is running.";
  }
}

async function loadQueue(id) {
  const target = document.getElementById(`queue-${id}`);
  target.textContent = "Calculating sample estimate…";
  try {
    const response = await fetch(`/api/queue/${id}`);
    const data = await response.json();
    target.textContent = `Estimated wait: ${data.estimated_wait_minutes} minutes. ${data.message}`;
  } catch {
    target.textContent = "Unable to load estimate.";
  }
}

appointmentForm.addEventListener("submit", async event => {
  event.preventDefault();
  appointmentMessage.className = "form-message";
  appointmentMessage.textContent = "Sending request…";
  const values = Object.fromEntries(new FormData(appointmentForm).entries());
  try {
    const response = await fetch("/api/appointments", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify(values)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed.");
    appointmentMessage.textContent = `${data.message} Request ID: ${data.appointment_id}.`;
    appointmentForm.reset();
  } catch (error) {
    appointmentMessage.classList.add("error");
    appointmentMessage.textContent = error.message;
  }
});

async function loadDoctorAppointments() {
  const body = document.getElementById("doctorRows");
  body.innerHTML = "<tr><td colspan='4'>Loading…</td></tr>";
  try {
    const response = await fetch("/api/doctor/appointments");
    const data = await response.json();
    if (!data.appointments.length) {
      body.innerHTML = "<tr><td colspan='4'>No demo appointment requests yet.</td></tr>";
      return;
    }
    body.innerHTML = "";
    data.appointments.forEach(a => {
      const tr = document.createElement("tr");
      [a.patient_name, a.hospital_name, a.preferred_time, `#${a.id}`].forEach(value => {
        const td = document.createElement("td");
        td.textContent = value;
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
  } catch {
    body.innerHTML = "<tr><td colspan='4'>Could not load requests.</td></tr>";
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[char]));
}

document.getElementById("refreshDoctor").addEventListener("click", loadDoctorAppointments);

let installPrompt;
window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  installPrompt = event;
  document.getElementById("installBtn").classList.remove("hidden");
});
document.getElementById("installBtn").addEventListener("click", async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  document.getElementById("installBtn").classList.add("hidden");
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/static/sw.js").catch(() => {}));
}
loadHospitals();
